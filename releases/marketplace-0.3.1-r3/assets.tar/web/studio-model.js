// A sablonmező átnevezése az összes deklaratív hivatkozást együtt változtatja meg.
export function renameField(spec, oldKey, nextKey) {
  if (!/^[a-z][a-z0-9_]{0,39}$/.test(nextKey)) throw new Error('FIELD_KEY');
  if (nextKey === oldKey) return;
  if (spec.fields.some(f => f.key === nextKey)) throw new Error('FIELD_DUPLICATE');
  const field = spec.fields.find(f => f.key === oldKey);
  if (!field) throw new Error('FIELD_MISSING');
  field.key = nextKey;
  for (const text of Object.values(spec.texts)) {
    if (Object.hasOwn(text.fields, oldKey)) {
      text.fields[nextKey] = text.fields[oldKey];
      delete text.fields[oldKey];
    }
  }
  const refs = new Set(['field', 'chronologicalField', 'whenMissingField', 'byField', 'allowedFromField']);
  const walk = (node) => {
    if (!node || typeof node !== 'object') return;
    for (const [key, value] of Object.entries(node)) {
      if (refs.has(key) && value === oldKey) node[key] = nextKey;
      else if (['fields', 'requireSame', 'dedupeBy'].includes(key) && Array.isArray(value) && value.every(x => typeof x === 'string')) node[key] = value.map(x => x === oldKey ? nextKey : x);
      else walk(value);
    }
  };
  for (const key of ['calculations','inputs','itemTables','comparison','computed','conditions','records']) walk(spec[key]);
  if (spec.chronologicalField === oldKey) spec.chronologicalField = nextKey;
  if (spec.anchors) spec.anchors = Object.fromEntries(Object.entries(spec.anchors).map(([key,value]) => [key === oldKey ? nextKey : key, value === oldKey ? nextKey : value]));
}

// A kezdeti azonosító emberi feliratból készül, és nem módosítja a látható üzleti szöveget.
export function suggestedKey(label, taken) {
  const base = label.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'').replace(/^([0-9])/,'m_$1').slice(0,32) || 'mezo';
  let key = base;
  for (let no=2;taken.includes(key);no++) key = `${base}_${no}`;
  return key;
}

// A sablon azonosítója és a csomag belépési hivatkozása mindig együtt változik.
export function renameTemplate(draft, spec, nextId) {
  if (!/^sablon-[a-z0-9]+(?:-[a-z0-9]+)*$/.test(nextId) || nextId.length > 70) throw new Error('TEMPLATE_ID');
  if (draft.templates.some(other => other !== spec && other.id === nextId)) throw new Error('TEMPLATE_DUPLICATE');
  const entries = draft.manifest.entrypoints.filter(entry => entry.templateId === spec.id);
  if (!entries.length) throw new Error('ENTRYPOINT');
  for (const entry of entries) entry.templateId = nextId;
  spec.id = nextId;
}
