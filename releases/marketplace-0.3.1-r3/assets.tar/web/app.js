import { businessEditor } from './studio-business.js';
import {topics as helpTopics} from './help.js';
import {renameField,renameTemplate,suggestedKey} from './studio-model.js';
// Helyi portál: minden felhasználói szöveg DOM-szövegként kerül a képernyőre.
const storageRead = (store, key) => { try { return store.getItem(key); } catch { return null; } };
let locale = storageRead(localStorage, "market.locale") === "en" ? "en" : "hu", user = null;
const t = (hu, en) => (locale === "hu" ? hu : en);
let token = storageRead(sessionStorage, "market.token") || "";
const view = document.querySelector("#view"),
  notice = document.querySelector("#notice");
const el = (tag, text, cls) => {
  const e = document.createElement(tag);
  if (text !== undefined) e.textContent = text;
  if (cls) e.className = cls;
  return e;
};
const add = (p, ...children) => {
  for (const c of children) if (c) p.append(c);
  return p;
};
const button = (text, fn, secondary = false) => {
  const b = el("button", text, secondary ? "secondary" : "");
  b.type = "button";
  b.onclick = async () => {
    b.disabled = true;
    try {
      notice.replaceChildren();
      await fn();
    } catch (e) {
      notice.className = "alert";
      notice.textContent = e.message;
    } finally {
      b.disabled = false;
    }
  };
  return b;
};
const input = (value = "", type = "text") => {
  const i = el("input");
  i.type = type;
  i.value = value;
  return i;
};
const area = (value) => {
  const a = el("textarea");
  a.value = value;
  return a;
};
const field = (p, label, node) => {
  const l = el("label", label);
  node.id = "f-" + crypto.randomUUID();
  l.htmlFor = node.id;
  add(p, l, node);
  return node;
};
// A box vonalas ikonkészletével azonos jelek; az API-adat mindig szövegként jelenik meg.
const paths = {
  bot:'M12 4v3M7 8h10a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2zM9.5 13h.01M14.5 13h.01M9 16.5h6M3 13v2M21 13v2',
  catalog:'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',
  studio:'M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z',
  library:'M3 6h6l2 2h10v12H3z',offers:'M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7',
  operator:'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z', developers:'M8 5l-7 7 7 7M16 5l7 7-7 7',login:'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
  help:'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01',
  search:'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-4.3-4.3',
  check:'M20 6L9 17l-5-5',sun:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5',
  moon:'M20.5 13A9 9 0 0 1 11 3.5 9 9 0 1 0 20.5 13z',menu:'M4 6h16M4 12h16M4 18h16',
  logout:'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9',
  flask:'M9 3h6M10 3v6L4 19a2 2 0 0 0 1.7 3h12.6a2 2 0 0 0 1.7-3L14 9V3',close:'M18 6L6 18M6 6l12 12'
};
function icon(name) { const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('fill','none');svg.setAttribute('stroke','currentColor');svg.setAttribute('stroke-width','1.8');svg.setAttribute('stroke-linecap','round');svg.setAttribute('stroke-linejoin','round');svg.setAttribute('aria-hidden','true');svg.classList.add('icon');const path=document.createElementNS(svg.namespaceURI,'path');path.setAttribute('d',paths[name]||paths.bot);svg.append(path);return svg; }
const stateName=(state)=>({review:t('Vizsgálatra vár','Awaiting review'),approved:t('Publikálásra kész','Ready to publish'),rejected:t('Javítást igényel','Needs changes'),published:t('Publikált','Published'),revoked:t('Visszavont','Revoked'),pending:t('Függőben','Pending'),paid:t('Teljesítve','Completed'),refunded:t('Visszatérítve','Refunded')})[state]||state;
const rightName=(kind)=>({U:t('Használat','Use'),D:t('Saját termék készítése','Create derivative'),R:t('Viszonteladás','Resale')})[kind]||kind;
function technical(summary,value) { return add(el('details'),el('summary',summary),el('pre',typeof value==='string'?value:json(value))); }
let helpOpen=false,helpId=null,helpReturn=null,renderedRoute=null;
function syncHelpMode() {
 const overlay=helpOpen && matchMedia('(max-width:1200px)').matches;
 document.querySelector('#main').inert=overlay;
 document.querySelector('.top').inert=overlay;
 document.querySelector('#sidebar').inert=overlay || (matchMedia('(max-width:850px)').matches && !document.body.classList.contains('nav-open'));
 const panel=document.querySelector('#help-panel');panel.setAttribute('role',overlay?'dialog':'complementary');
 if(overlay)panel.setAttribute('aria-modal','true');else panel.removeAttribute('aria-modal');
}
function closeHelp() { const overlay=document.querySelector('#help-overlay');if(overlay?.open){overlay.close();document.querySelector('.layout').append(document.querySelector('#help-panel'));}helpOpen=false;document.querySelector('#help-panel').hidden=true;document.body.classList.remove('help-open');document.querySelector('#help-toggle').setAttribute('aria-expanded','false');syncHelpMode();helpReturn?.focus(); }
function openHelp(id) { if(!helpOpen)navClose();helpId=id||location.hash.slice(1)||'catalog';helpReturn=document.activeElement;helpOpen=true;drawHelp();document.querySelector('#help-panel').hidden=false;document.body.classList.add('help-open');document.querySelector('#help-toggle').setAttribute('aria-expanded','true');if(document.querySelector('#dialog').open){let overlay=document.querySelector('#help-overlay');if(!overlay){overlay=el('dialog');overlay.id='help-overlay';overlay.setAttribute('aria-label',t('Súgó','Help'));overlay.addEventListener('cancel',e=>{e.preventDefault();closeHelp();});document.body.append(overlay);}overlay.append(document.querySelector('#help-panel'));overlay.showModal();}syncHelpMode();document.querySelector('#help-search').focus(); }
function drawHelp() {
 const panel=document.querySelector('#help-panel');panel.replaceChildren();panel.setAttribute('aria-label',t('Súgó','Help'));
 const close=button(t('Súgó bezárása','Close help'),closeHelp,true);close.classList.add('icon-button');close.setAttribute('aria-label',t('Súgó bezárása','Close help'));close.replaceChildren(icon('close'));
 add(panel,add(el('div',undefined,'help-head'),el('h2',t('Súgó','Help')),close));
 const search=input();search.id='help-search';search.setAttribute('aria-label',t('Keresés a súgóban','Search help'));search.placeholder=t('Miben segíthetünk?','How can we help?');panel.append(search);
 const body=el('div');panel.append(body);const topics=helpTopics(locale==='en');
 const draw=()=>{body.replaceChildren();const q=search.value.trim().toLowerCase();const selected=topics.find(x=>x.id===helpId)||topics[0];const items=q?topics.filter(x=>[x.title,x.intro,...x.steps].join(' ').toLowerCase().includes(q)):[selected];
  for(const topic of items){const section=el('section',undefined,'help-topic');add(section,el('h2',topic.title),el('p',topic.intro));const steps=el('ol');for(const step of topic.steps)steps.append(el('li',step));section.append(steps);for(const id of topic.related){const related=topics.find(x=>x.id===id);if(related)section.append(button(related.title,()=>{helpId=id;search.value='';draw();},true));}body.append(section);}
  if(!items.length)body.append(add(empty(t('Nincs találat. Próbálj más keresőszót.','No results. Try another term.')),button(t('Keresés törlése','Clear search'),()=>{search.value='';draw();},true)));
  const all=technical(t('Összes súgótéma','All help topics'),'');all.lastChild.remove();for(const topic of topics)all.append(button(topic.title,()=>{helpId=topic.id;search.value='';draw();},true));body.append(all);
 };search.oninput=draw;draw();
}
function navClose() { document.body.classList.remove('nav-open');document.querySelector('#nav-backdrop').hidden=true;document.querySelector('#nav-toggle').setAttribute('aria-expanded','false');document.querySelector('#sidebar').inert=matchMedia('(max-width:850px)').matches; }
function syncShell() {
 document.querySelector('#help-toggle').replaceChildren(icon('help'),el('span',t('Súgó','Help'),'button-label'));
 document.querySelector('#help-toggle').setAttribute('aria-label',t('Súgó','Help'));
 const light=document.documentElement.dataset.theme==='light';document.querySelector('#theme').replaceChildren(icon(light?'moon':'sun'));document.querySelector('#theme').setAttribute('aria-label',light?t('Sötét megjelenés','Dark appearance'):t('Világos megjelenés','Light appearance'));
 document.querySelector('#logout').replaceChildren(icon('logout'));document.querySelector('#logout').setAttribute('aria-label',t('Kilépés','Sign out'));
 document.querySelector('#nav-toggle').replaceChildren(icon('menu'));document.querySelector('#nav-toggle').setAttribute('aria-label',t('Menü megnyitása','Open menu'));
 document.querySelector('#account-label').textContent=user?user.email:t('Böngéssz, vagy lépj be a saját fiókodba.','Explore, or sign in to your account.');
 document.querySelector('.skip-link').textContent=t('Ugrás a tartalomra','Skip to content');
}

const json = (x) => JSON.stringify(x, null, 2);
async function api(url, body, raw = false) {
  const r = await fetch(url, {
    method: body === undefined ? "GET" : "POST",
    headers: {
      "accept-language":locale,
      ...(token ? { authorization: "Bearer " + token } : {}),
      ...(body === undefined ? {} : { "content-type": "application/json" }),
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  if (!r.ok) {
    let b;
    try {
      b = await r.json();
    } catch {}
    throw new Error(
      locale === "hu"
        ? b?.error?.message || "Hiba"
        : b?.error?.message || "The request could not be completed.",
    );
  }
  return raw ? r.blob() : r.json();
}
function save(blob, name) {
  const a = el("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
const base64 = async (file) => {
  if (!file || file.size > 25 * 1024 * 1024)
    throw new Error(t("Legfeljebb 25 MiB méretű csomag választható.", "Choose a package no larger than 25 MiB."));
  const b = new Uint8Array(await file.arrayBuffer());
  let s = "";
  for (let i = 0; i < b.length; i += 8192)
    s += String.fromCharCode(...b.subarray(i, i + 8192));
  return btoa(s);
};
const unbase64 = (s) =>
  new Blob([Uint8Array.from(atob(s), (c) => c.charCodeAt(0))], {
    type: "application/octet-stream",
  });
const date = (n) => new Date(n).toLocaleString(locale);
function modal(title, body, helpTopic = location.hash.slice(1) || "catalog") {
  const d = document.querySelector("#dialog"),
    c = document.querySelector("#dialog-content");
  const heading=el("h2",title);heading.id="dialog-title";const help=button(t('Súgó ehhez','Help for this'),()=>openHelp(helpTopic),true);help.classList.add('dialog-help');c.replaceChildren(heading,body,help);
  d.showModal();
}
function empty(text) {
  return el("div", text, "empty");
}
function requireUser() {
  if (!user) {
    location.hash = "login";
    return false;
  }
  return true;
}
function header(title, description) {
 const page=location.hash.slice(1)||'catalog';const h=el('div',undefined,'hero');
 const copy=el('div');add(copy,el('div',t('AI-SABLONOK · VIVETECH','AI TEMPLATES · VIVETECH'),'kicker'),el('h1',title),el('p',description));
 add(h,copy,add(el('div',undefined,'hero-art'),icon(page)));view.append(h);
}

let rendering = false,
  renderRequested = false;
async function render() {
  if (rendering) {
    renderRequested = true;
    return;
  }
  rendering = true;
  const expanded=location.hash==='#studio'?[...view.querySelectorAll('details')].map(d=>d.open):[];
  try {
    do {
      renderRequested = false;
      await renderPage();
    } while (renderRequested);
    if(location.hash==='#studio')[...view.querySelectorAll('details')].forEach((d,i)=>{if(expanded[i])d.open=true;});
    persistStudio();
  } finally {
    rendering = false;
  }
}
async function renderPage() {
  view.replaceChildren();
  notice.replaceChildren();
  const page = location.hash.slice(1) || "catalog";
  document.documentElement.lang = locale;
  document.querySelector('#locale').setAttribute('aria-label',t('Nyelv','Language'));
  document.querySelector('#nav').setAttribute('aria-label',t('Főmenü','Main menu'));
  document.querySelector('#nav-backdrop').setAttribute('aria-label',t('Menü bezárása','Close menu'));
  document.querySelector('#dialog .close').setAttribute('aria-label',t('Bezárás','Close'));
  document.querySelector("#test-banner").replaceChildren(icon('flask'),el('span',t('Tesztvásárlás · nincs pénzmozgás','Test purchases · no money movement')));
  document.querySelector("#test-banner").title=t('A vásárlás és az elszámolás helyi tesztüzemben fut.','Purchases and settlements run in local test mode.');
  syncShell();
  if(helpOpen){if(renderedRoute!==page)helpId=page;drawHelp();}
  renderedRoute=page;
  const nav = document.querySelector("#nav");
  nav.replaceChildren();
  for (const [key, hu, en] of [
    ["catalog", "Katalógus", "Catalog"],
    ["offers", "Viszonteladók", "Resellers"],
    ["studio", "Studio", "Studio"],
    ["library", "Saját könyvtár", "My library"],
    ["developers", "SDK és súgó", "SDK & help"],
    ...(user?.operator ? [["operator", "Üzemeltetés", "Operations"]] : []),
    ...(!user ? [["login", "Belépés", "Sign in"]] : []),
  ]) {
    const a = el("a", undefined, page === key ? "active" : "");
    add(a,icon(key),el("span",t(hu,en)));
    if(page===key)a.setAttribute("aria-current","page");
    a.onclick=navClose;
    a.href = "#" + key;
    nav.append(a);
  }
  document.querySelector("#logout").hidden = !user;

  try {
    if (page === "catalog") await catalog();
    else if (page === "offers") await offers();
    else if (page === "login") login();
    else if (page === "studio" && requireUser()) await studio();
    else if (page === "library" && requireUser()) await library();
    else if (page === "operator" && requireUser()) await operator();
    else if (page === "developers") help();
  } catch (e) {
    notice.className = "alert";
    notice.textContent = e.message;
  }
}
async function catalog() {
 header(t('AI-sablonok a saját boxodra','AI templates for your box'),t('Találd meg a feladatodhoz illő sablont. Vásárold meg, telepítsd a boxodra, és készíts belőle saját ügynököt.','Find a template for your task. Acquire it, install it on your box and create your own agent.'));
 const tools=el('div',undefined,'catalog-tools'),search=input();search.placeholder=t('Keresés név, kiadó vagy feladat szerint…','Search name, publisher or task…');search.setAttribute('aria-label',search.placeholder);
 const filter=el('select');filter.setAttribute('aria-label',t('Árszűrő','Price filter'));for(const [value,hu,en] of [['all','Minden csomag','All packages'],['free','Ingyenes','Free']]){const o=el('option',t(hu,en));o.value=value;filter.append(o);}
 const count=el('span',undefined,'result-count');add(tools,add(el('div',undefined,'search-wrap'),icon('search'),search),filter,count);view.append(tools);
 const grid=el('div',undefined,'cards');view.append(grid);const list=await api('/market/v1/catalog');
 const draw=()=>{grid.replaceChildren();const matches=list.filter(r=>json(r.manifest).toLowerCase().includes(search.value.toLowerCase())&&(filter.value!=='free'||r.price===0));count.textContent=t(`${matches.length} csomag`,`${matches.length} packages`);
  for(const r of matches){const m=r.manifest,c=el('article',undefined,'card package-card');
   add(c,add(el('div',undefined,'package-meta'),add(el('div',undefined,'package-icon'),icon('bot')),el('span',m.publisherId)),el('h2',m.title),el('p',m.description,'package-description'),add(el('div',undefined,'row'),el('span','v'+m.version,'badge'),add(el('span',undefined,'badge ok'),icon('check'),el('span',t('Ellenőrzött csomag','Reviewed package')))),add(el('div',undefined,'card-footer'),el('strong',r.price===0?t('Ingyenes','Free'):`${r.price.toLocaleString(locale==='hu'?'hu-HU':'en-GB')} HUF`,'price'),button(t('Részletek és jogok','Details & rights'),()=>details(r),true)));grid.append(c);
  }
  if(!matches.length){const e=empty('');add(e,add(el('div',undefined,'package-icon'),icon('search')),el('h2',t('Nincs találat','No matches')),el('p',t('Próbálj más keresőszót vagy nézd meg az összes csomagot.','Try another search term or view all packages.')),button(t('Szűrők törlése','Clear filters'),()=>{search.value='';filter.value='all';draw();},true));grid.append(e);}
 };search.oninput=draw;filter.onchange=draw;draw();
}

async function details(r) {
  const m = r.manifest,
    c = el("div");
  add(
    c,
    el("p", m.description),
    el('p',t('A csomag a kiválasztott dokumentumokat olvashatja, az eredményt jóváhagyással mentheti.','The package can read selected documents and save results with approval.')),
    technical(t('Műszaki részletek','Technical details'),{permissions:m.permissions,capabilities:m.requires.capabilities,editable:m.license.editable}),
  );
  for (const [kind, available, hu, en] of [
    ["U", true, "Használati jog", "Use license"],
    [
      "D",
      m.license.derivatives && !m.derivedFrom,
      "Származtatási és eladási jog",
      "Derivative sales right",
    ],
    ["R", m.license.resale, "Viszonteladói jog", "Reseller right"],
  ])
    if (available)
      add(
        c,
        add(el('div',undefined,'right-card'),el('span',kind,'badge info'),add(el('div'),el('strong',t(hu,en)),el('p',kind==='U'?t('Telepítés és használat a saját boxodon.','Install and use on your own box.'):kind==='D'?t('Átalakítás és új saját termék készítése.','Adapt and create a new product.'):t('Az eredeti csomag változatlan értékesítése, saját áron.','Sell the original unchanged package at your own price.')))),
        button(
          t(hu, en) + " • " + t("tesztvásárlás", "test purchase"),
          async () => {
            if (!requireUser()) {
              document.querySelector("#dialog").close();
              return;
            }
            const b = el("div");
            add(
              b,
              el(
                "p",
                t("Helyi tesztvásárlás: ", "Local test purchase: ") +
                  r.price +
                  " HUF / " +
                  kind,
              ),
              el(
                "p",
                t(
                  "Nincs valódi fizetés. A tesztjogosultság a szervezetedhez kerül.",
                  "No real payment. A test entitlement will be assigned to your organization.",
                ),
              ),
              button(
                t("Tesztvásárlás megerősítése", "Confirm test purchase"),
                async () => {
                  const o = await api("/market/v1/orders", {
                    digest: r.digest,
                    kind,
                    idempotencyKey: crypto.randomUUID(),
                  });
                  await api(
                    "/market/v1/orders/" + o.id + "/local-test-complete",
                    {},
                  );
                  document.querySelector("#dialog").close();
                  location.hash = "library";
                  await render();
                },
              ),
            );
            document.querySelector("#dialog").close();
            modal(m.title, b);
          },
        ),
      );
  modal(m.title, c);
}
function login() {
  header(
    t("Belépés a központba", "Sign in to the marketplace"),
    t(
      "A Studio-fiók és a box felhasználója külön jogosultsági kör.",
      "Studio accounts and box users have separate permissions.",
    ),
  );
  const f = el("form", undefined, "card formwrap"),
    email = field(f, t("E-mail", "Email"), input("", "email")),
    password = field(
      f,
      t("Jelszó • legalább 12 karakter", "Password • minimum 12 characters"),
      input("", "password"),
    );
  email.autocomplete="username";
  email.required=true;
  password.required=true;
  password.autocomplete = "current-password";
  const done = async () => {
    const r = await api("/market/v1/login", {
      email: email.value,
      password: password.value,
    });
    token = r.token;
    sessionStorage.setItem("market.token", token);
    user = r.user;
    location.hash = "studio";
    await render();
  };
  f.onsubmit=async e=>{e.preventDefault();try{await done();}catch(error){notice.className='alert';notice.textContent=error.message;}};
  f.onkeydown=e=>{if(e.key==='Enter'&&e.target.tagName==='INPUT'){e.preventDefault();f.requestSubmit();}};
  add(
    f,
    el(
      "div",
      t(
        "Szerzőként és vásárlóként is ugyanazt a piactéri fiókot használhatod.",
        "Use the same marketplace account for authoring and purchasing.",
      ),
      "muted",
    ),
    add(
      el("div", undefined, "actions"),
      button(t("Belépés", "Sign in"), done),
      button(
        t("Saját fiók létrehozása", "Create account"),
        async () => {
          await api("/market/v1/register", {
            email: email.value,
            password: password.value,
          });
          await done();
        },
        true,
      ),
    ),
  );
  view.append(f);
}
let draft = null,
  projectId = null,
  revision = null,
  draftPrice = "0";
let rawDraft = null, savedStudioFingerprint='';
function clearStudio() {
  draft=null;rawDraft=null;projectId=null;revision=null;draftPrice='0';savedStudioFingerprint='';
  if(user)try{sessionStorage.removeItem('market.draft.'+user.id);}catch{}
}
function deleteProject(project) {
  const content=add(el('div'),el('p',t(`Végleg törlöd a(z) „${project.title}” privát projektet?`,`Permanently delete the private project “${project.title}”?`)),
    el('p',t('A mentetlen szerkesztés is elvész. A beküldött és publikált kiadások, licencek és telepített sablonok megmaradnak.','Unsaved edits will also be lost. Submitted and published releases, licenses and installed templates are retained.')));
  if(project.ownerEmail)content.append(el('p',t('Tulajdonos: ','Owner: ')+project.ownerEmail));
  add(content,add(el('div',undefined,'actions'),
    button(t('Mégse','Cancel'),()=>document.querySelector('#dialog').close(),true),
    button(t('Privát projekt végleges törlése','Permanently delete private project'),async()=>{
      await api('/studio/v1/projects/'+project.id+'/delete',{revision:project.revision,confirm:true});
      if(projectId===project.id)clearStudio();
      document.querySelector('#dialog').close();await render();
      notice.textContent=t('A privát projekt törölve.','Private project deleted.');
    })));
  modal(t('Privát projekt törlése','Delete private project'),content,'studio');
}
const studioFingerprint=()=>json({draft,price:draftPrice});
const persistStudio=()=>{if(user&&draft)try{sessionStorage.setItem('market.draft.'+user.id,json({draft,rawDraft,projectId,revision,draftPrice,savedStudioFingerprint}));}catch{}};
const canReplaceStudio=()=>!draft||rawDraft===null&&studioFingerprint()===savedStudioFingerprint||confirm(t('Az aktuális mentetlen szerkesztés lecserélődik. Mentsd privátként, ha meg szeretnéd őrizni. Folytatod?','Your current unsaved edits will be replaced. Save privately first to keep them. Continue?'));
window.addEventListener('beforeunload',persistStudio);
view.addEventListener('input',persistStudio);
view.addEventListener('change',persistStudio);
async function studio() {
  user = await api("/market/v1/me");
  if(!draft)try{const stored=JSON.parse(sessionStorage.getItem('market.draft.'+user.id)??'null');if(stored?.draft){({draft,rawDraft,projectId,revision,draftPrice,savedStudioFingerprint}=stored);}}catch{}
  header(
    "Studio",
    t(
      "Készíts hordozható sablont, vagy folytasd egy meglévő csomag fejlesztését.",
      "Create a portable template or continue working on an existing package.",
    ),
  );
  if (!user.publisher) {
    const p = el("div", undefined, "card"),
      name = field(
        p,
        t("Saját kiadói névtér", "Publisher namespace"),
        input("sajatkiado"),
      );
    add(
      p,
      button(t("Névtér igénylése", "Request namespace"), async () => {
        user = await api("/market/v1/publisher", { publisherId: name.value });
        await render();
      }),
    );
    view.append(p);
    return;
  }
  view.append(
    el(
      "p",
      user.publisher +
        " • " +
        (user.verified
          ? t("jóváhagyott kiadó", "approved publisher")
          : t("kiadói jóváhagyásra vár", "publisher approval pending")),
    ),
  );
  const steps=el('div',undefined,'studio-stepper');
  for(const [i,hu,en,descHu,descEn] of [[1,'Szerkesztés','Authoring','Privát projekt','Private project'],[2,'Ellenőrzés','Review','Csomag és kiadó','Package and publisher'],[3,'Publikálás','Publish','Megjelenés a katalógusban','List in catalog']])add(steps,add(el('div',undefined,'studio-step'),el('span',String(i),'step-number'),add(el('div'),el('strong',t(hu,en)),el('span',t(descHu,descEn)))));
  view.append(steps);
  const projects = await api("/studio/v1/projects");
  const toolbar = el("div", undefined, "actions");
  add(
    toolbar,
    button(t("Új sablon", "New template"), async () => {
      if(!canReplaceStudio())return;
      rawDraft = null;
      draft = await api("/studio/v1/new?locale="+locale);
      projectId = null;
      revision = null;
      draftPrice = "0";
      await render();
    }, !!draft),
    button(t('Mintasablon betöltése','Load example template'),async()=>{
      if(!canReplaceStudio())return;
      draft=await api('/studio/v1/example');rawDraft=null;projectId=null;revision=null;draftPrice='0';
      draft.manifest.license={editable:false,derivatives:false,resale:false};await render();
    },true),
    button(
      t("Csomag importálása", "Import package"),
      async () => {
        const f = input("", "file");
        f.accept = ".vtaip";
        f.onchange = async () => {
          try {
            if(!canReplaceStudio())return;
            const p = await api("/studio/v1/validate", {
              archive: await base64(f.files[0]),
            });
            rawDraft = null;
            draft = { manifest: p.manifest, templates: p.templates,assets:p.assets??{} };
            projectId = null;
            revision = null;
            draftPrice = "0";
            await render();
          } catch (e) {
            notice.className = "alert";
            notice.textContent = e.message;
          }
        };
        f.click();
      },
      true,
    ),
  );
  view.append(toolbar);
  if (projects.length) {
    const list = el("select");
    list.setAttribute("aria-label", t("Projekt megnyitása", "Open project"));
    add(
      list,
      Object.assign(el("option", t("Mentett projekt kiválasztása…", "Select saved project…")), {value: ""}),
    );
    for (const p of projects) {
      const o = el("option", p.title);
      o.value = p.id;
      list.append(o);
    }
    list.value = projectId || "";
    list.onchange = async () => {
      if (!list.value.startsWith("project-")) return;
      if(!canReplaceStudio()){list.value=projectId??"";return;}
      const p = await api("/studio/v1/projects/" + list.value);
      projectId = p.id;
      revision = p.revision;
      rawDraft = null;
      draft = {manifest:p.body.manifest,templates:p.body.templates,assets:p.body.assets??{}};
      draftPrice = String(p.body.studio?.price ?? 0);
      savedStudioFingerprint=studioFingerprint();persistStudio();
      await render();
    };
    list.classList.add("project-picker");
    toolbar.append(list);
    const current=projects.find(p=>p.id===projectId);
    if(current)toolbar.append(button(t('Projekt törlése','Delete project'),()=>deleteProject({...current,revision}),true));
  }
  const releases = await api("/studio/v1/releases");
  const releaseSection=add(el('details'),el('summary',t(`Kiadásaim (${releases.length})`,`My releases (${releases.length})`)));
  const releaseGrid=el('div',undefined,'cards');releaseSection.append(releaseGrid);
  for (const r of releases) {
    const c = el("div", undefined, "card");
    add(
      c,
      el("strong", r.manifest.title + " / " + r.manifest.version),
      el("span", stateName(r.state), "badge " + (r.state === "published" || r.state === "approved" ? "ok" : "warn")),
      r.review ? el("p", r.review.note) : null,
    );
    if (r.state === "approved")
      add(
        c,
        button(t("Publikálás", "Publish"), async () => {
          await api("/studio/v1/releases/" + r.digest + "/publish", {});
          await render();
        }),
      );
    releaseGrid.append(c);
  }
  if(releases.length)toolbar.append(button(t('Kiadásaim','My releases'),()=>{releaseSection.open=true;releaseSection.scrollIntoView({behavior:'smooth',block:'start'});},true));
  if (!draft) {
    view.append(
      empty(
        t(
          "Válassz projektet vagy készíts új sablont.",
          "Select a project or create a new template.",
        ),
      ),
    );
    view.append(releaseSection);
    return;
  }
  const split = el("div", undefined, "split");
  split.classList.add("spaced");
  const editor = el("section", undefined, "card studio-editor"),
    side = el("section", undefined, "card studio-side");
  add(split, editor, side);
  view.append(split);
  const m = draft.manifest,
    s = draft.templates[0];
  let raw;
  const syncRaw = () => { if (raw && rawDraft === null) raw.value = json(draft);persistStudio(); };
  const committed = (requireIdentity = true) => {
    if (rawDraft !== null) throw new Error(t('A JSON módosításait előbb alkalmazd vagy vesd el.','Apply or discard your JSON changes first.'));
    const invalid = [...split.querySelectorAll(':invalid')].find(control=>requireIdentity||!control.hasAttribute('data-identity'));
    if (invalid) { invalid.reportValidity(); throw new Error(t('Javítsd a jelzett mezőt mentés előtt.','Correct the highlighted field before saving.')); }
    syncRaw();
    return draft;
  };
  editor.addEventListener('input', syncRaw);
  editor.addEventListener('change', syncRaw);
  editor.append(el('h2',t('Sablon adatai','Template details')));

  const nameControl=field(editor, t("Sablon neve", "Template name"), input(m.title));
  nameControl.required=true;nameControl.maxLength=120;nameControl.dataset.identity='';
  const sourceControls={name:nameControl};
  nameControl.oninput = (
    e,
  ) => {
    m.title = e.target.value;
    s.texts[s.sourceLocale].name = e.target.value;
    if(sourceControls.localizedName)sourceControls.localizedName.value=e.target.value;
  };
  const templateId=field(editor,t('Sablonazonosító','Template identifier'),input(s.id));
  templateId.required=true;templateId.maxLength=70;templateId.dataset.identity='';templateId.placeholder='sablon-sajat-feladat';
  templateId.oninput=()=>{
    try{renameTemplate(draft,s,templateId.value);templateId.setCustomValidity('');}
    catch{templateId.setCustomValidity(t('Használj sablon- kezdetet, kisbetűket, számokat és kötőjelet; az azonosító legyen egyedi.','Use a unique identifier starting with sablon-, followed by lowercase letters, digits and hyphens.'));}
  };
  const packageId=field(editor,t('Csomagazonosító','Package identifier'),input(m.packageId));
  packageId.required=true;packageId.dataset.identity='';packageId.placeholder=user.publisher+'.sajat-feladat';
  packageId.oninput=()=>{
    m.packageId=packageId.value;
    const prefix=user.publisher+'.',suffix=packageId.value.slice(prefix.length);
    packageId.setCustomValidity(packageId.value.startsWith(prefix)&&/^[a-z][a-z0-9-]{1,60}$/.test(suffix)?'':t('A saját kiadói névtered után pont, majd kisbetűs csomagnév szükséges.','Use your publisher namespace, a dot, and a lowercase package name.'));
  };
  editor.append(el('p',t('A név a csomagban és a sablon forrásnyelvén is frissül. A sablonazonosító a belépési hivatkozást is átírja; a csomagazonosító külön, a saját kiadói névteredben él.','The name updates both the package and the template source language. Changing the template identifier also updates its entrypoint; the separate package identifier belongs to your publisher namespace.'),'muted'));
  const identifiers=add(el('details'),el('summary',t('Azonosítók és verzió','Identifiers and version')));editor.append(identifiers);
  field(identifiers, t("Verzió", "Version"), input(m.version)).oninput = (e) =>
    (m.version = e.target.value);
  const descriptionControl=field(editor, t("Leírás", "Description"), input(m.description));
  sourceControls.description=descriptionControl;
  descriptionControl.oninput = (
    e,
  ) => {m.description = e.target.value;s.texts[s.sourceLocale].description=e.target.value;if(sourceControls.localizedDescription)sourceControls.localizedDescription.value=e.target.value;};
  const tx = s.texts[s.sourceLocale];
  const task = field(editor,t('Alapfeladat','Default task'),area(tx.defaultTask));sourceControls.defaultTask=task;task.oninput=()=>{tx.defaultTask=task.value;if(sourceControls.localizedDefaultTask)sourceControls.localizedDefaultTask.value=task.value;};
  const brief = field(editor,t('Rövid leírás','Short description'),input(tx.shortDescription));sourceControls.shortDescription=brief;brief.oninput=()=>{tx.shortDescription=brief.value;if(sourceControls.localizedShortDescription)sourceControls.localizedShortDescription.value=brief.value;};
  add(editor, el("h2", t("Kinyerendő mezők", "Extraction fields")));
  const fieldList = el("div");
  editor.append(fieldList);
  function fields() {
    fieldList.replaceChildren();
    s.fields.forEach((f, i) => {
      const row = el("div", undefined, "field"),
        key = input(f.key),
        label = input(s.texts[s.sourceLocale].fields[f.key]?.label || f.key),
        type = el("select");
      key.setAttribute("aria-label", t("Mezőkulcs", "Field key"));
      label.setAttribute("aria-label", t("Felirat", "Label"));
      type.setAttribute("aria-label", t("Típus", "Type"));
      for (const v of ["text", "date", "money", "number", "percent"]) {
        const labels={text:t("Szöveg","Text"),date:t("Dátum","Date"),money:t("Pénzösszeg","Money"),number:t("Szám","Number"),percent:t("Százalék","Percent")};
        const o = el("option", labels[v]);
        o.value = v;
        type.append(o);
      }
      type.value = f.type;
      key.oninput = (e) => {
        const old = f.key,
          n = e.target.value;
        try { renameField(s,old,n); for(const opt of editor.querySelectorAll('option[data-field-key]'))if(opt.dataset.fieldKey===old){opt.value=n;opt.dataset.fieldKey=n;}key.setCustomValidity(''); }
        catch { key.setCustomValidity(t('Egyedi kulcs szükséges: kisbetű, szám és aláhúzás, betűvel kezdve.','Use a unique key starting with a letter, then lowercase letters, digits or underscores.')); }
      };
      label.oninput = (e) =>
        (s.texts[s.sourceLocale].fields[f.key].label = e.target.value);
      type.onchange = (e) => (f.type = e.target.value);
      const controls=[['Mezőkulcs','Field key',key],['Felirat','Label',label],['Típus','Type',type]].map(([hu,en,node])=>{const c=el(node===key?'details':'div',undefined,'field-control');if(node===key)c.append(el('summary',t('Technikai mezőkulcs','Technical field key')));field(c,t(hu,en),node);return c;});
      add(
        row,
        ...controls,
        button(
          t("Törlés", "Remove"),
          () => {
            s.fields.splice(i, 1);
            s.calculations = s.calculations.filter((c) => c.field !== f.key);
            for (const l of Object.values(s.texts)) delete l.fields[f.key];
            fields();
            syncRaw();
          },
          true,
        ),
      );
      const remove=row.querySelector('button');remove.setAttribute('aria-label',t('Mező törlése','Remove field'));remove.title=remove.getAttribute('aria-label');remove.replaceChildren(icon('close'));
      const ft=s.texts[s.sourceLocale].fields[f.key];
      const descGroup=el('div',undefined,'field-detail'),hintGroup=el('div',undefined,'field-detail');add(row,descGroup,hintGroup);
      const description=field(descGroup,t('Mit keressen az AI?','What should AI look for?'),area(ft.description));description.oninput=()=>{ft.description=description.value;};
      const hints=field(hintGroup,t('Forrásbeli elnevezések, vesszővel','Source labels, comma-separated'),input(ft.hints.join(', ')));hints.oninput=()=>{ft.hints=hints.value.split(',').map(x=>x.trim()).filter(Boolean);};
      const required=input('','checkbox');required.checked=f.required;required.onchange=()=>{f.required=required.checked;};add(row,add(el('label',undefined,'field-required'),required,el('span',t('Kötelező adat','Required data'))));
      fieldList.append(row);
    });
  }
  fields();
  const languageTexts=add(el('details'),el('summary',t('A sablon nyelvei','Template languages')));editor.append(languageTexts);
  for(const code of ['hu','en']) {
    if(!s.texts[code]){languageTexts.append(button(code==='en'?t('Angol tartalom hozzáadása','Add English content'):t('Magyar tartalom hozzáadása','Add Hungarian content'),()=>{s.texts[code]=structuredClone(s.texts[s.sourceLocale]);m.locales=[...new Set([...m.locales,code])];syncRaw();void render();},true));continue;}
    const tx=s.texts[code],group=add(el('fieldset'),el('legend',code==='hu'?t('Magyar tartalom','Hungarian content'):t('Angol tartalom','English content')));languageTexts.append(group);
    for(const [key,hu,en] of [['name','Sablon neve','Template name'],['shortDescription','Rövid leírás','Short description'],['description','Leírás','Description'],['defaultTask','Alapfeladat','Default task']]){
      const control=field(group,t(hu,en)+(code==='hu'?t(' (magyar)',' (Hungarian)'):t(' (angol)',' (English)')),area(tx[key]));
      if(code===s.sourceLocale)sourceControls['localized'+key[0].toUpperCase()+key.slice(1)]=control;
      control.oninput=()=>{tx[key]=control.value;if(code===s.sourceLocale){sourceControls[key].value=control.value;if(key==='name')m.title=control.value;if(key==='description')m.description=control.value;}syncRaw();};
    }
    for(const f of s.fields){const ft=tx.fields[f.key];const box=add(el('fieldset'),el('legend',ft.label));group.append(box);for(const [key,hu,en] of [['label','Felirat','Label'],['description','AI-leírás','AI description'],['hints','Forrásbeli elnevezések','Source labels']]){const control=field(box,t(hu,en),area(key==='hints'?ft.hints.join(', '):ft[key]));control.oninput=()=>{ft[key]=key==='hints'?control.value.split(',').map(x=>x.trim()).filter(Boolean):control.value;syncRaw();};}}
  }
  add(
    editor,
    button(
      t("Mező hozzáadása", "Add field"),
      () => {
        const k = suggestedKey(t('Új mező','New field'),s.fields.map(f=>f.key));
        s.fields.push({ key: k, type: "text", required: false });
        for (const l of Object.values(s.texts))
          l.fields[k] = { label: t('Új mező','New field'), description: '', hints: [] };
        fields();
        syncRaw();
      },
      true,
    ),
  );
  add(
    side,
    el("h2", t("Csomag és kiadás", "Package & release")),
    el(
      "p",
      t(
        "A vizsgálat itt a sémát és a hordozhatóságot ellenőrzi. Ez nem valódi AI-minősítés.",
        "Validation checks schema and portability. This is not real AI certification.",
      ),
    ),
  );
  const price = field(
    side,
    t("Helyi tesztár (HUF)", "Local test price (HUF)"),
    input(draftPrice, "number"),
  );
  price.oninput=()=>{draftPrice=price.value;};
  price.min = "0";
  price.step = "1";
  price.max = "100000000";
  businessEditor(s,m,editor,{el,add,field,input,area,button,t,changed:(refresh)=>{syncRaw();if(refresh)void render();}});
  const aiDescription=field(side,t('Milyen sablont szeretnél?','What template would you like?'),area(m.description));
  add(side,el('p',t('A leírás a kiválasztott saját Box helyi AI-jához kerül; a sablonjavaslat visszakerül a Studio-ba. Dokumentumot ez a művelet nem küld. A Boxon külön engedélyezni kell a Studio-segédet.','Your description goes to the selected Box local AI, and the template suggestion returns to Studio. This operation does not send documents. Enable Studio assistance separately on the Box.')));
  const ownBoxes=(await api('/market/v1/library')).boxes;
  const aiBox=el('select');aiBox.setAttribute('aria-label',t('A helyi AI Box','Local AI Box'));for(const bx of ownBoxes){const opt=el('option',bx.name);opt.value=bx.id;aiBox.append(opt);}if(ownBoxes.length)side.append(aiBox);else{const link=el('a',t('A helyi AI segítségéhez csatlakoztasd a saját Boxodat a Saját könyvtárban.','Connect your Box in My library to use local AI assistance.'));link.href='#library';side.append(link);}
  if(ownBoxes.length)add(side,button(t('AI-sablonjavaslat','AI template suggestion'),async()=>{
    committed(false);const requested=await api('/studio/v1/assist',{boxId:aiBox.value,description:aiDescription.value,locale});
    notice.textContent=t('A helyi Box sablonjavaslatán dolgozik…','The local Box is preparing a template suggestion…');
    let result;
    for(let attempt=0;attempt<120;attempt++){await new Promise(resolve=>setTimeout(resolve,1500));const response=await api('/studio/v1/assist/'+requested.id);if(response.state==='failed')throw new Error(response.result.error);if(response.state==='done'){result=response.result;break;}}
    if(!result)throw new Error(t('A Box nem válaszolt időben.','The Box did not respond in time.'));
    const preview=add(el('div'),el('p',t(result.simulated?'Szimulált javaslat – nem valódi AI.':'Helyi AI-javaslat; alkalmazás előtt ellenőrizd. ',result.simulated?'Simulated suggestion – not genuine AI.':'Local AI suggestion; review before applying.')));
    const tx=result.spec.texts[result.spec.sourceLocale];add(preview,el('h3',tx.name),el('p',tx.defaultTask),el('ul',undefined));for(const f of result.spec.fields)preview.querySelector('ul').append(el('li',tx.fields[f.key].label+' · '+tx.fields[f.key].description));for(const warning of result.warnings)preview.append(el('p',warning));
    preview.append(button(t('Javaslat alkalmazása a tervezetre','Apply suggestion to draft'),async()=>{committed(false);const next=result.spec;next.id=draft.templates[0].id;if(draft.manifest.title.trim())next.texts[next.sourceLocale].name=draft.manifest.title;draft.templates[0]=next;draft.manifest.locales=[next.sourceLocale];draft.manifest.title=next.texts[next.sourceLocale].name;draft.manifest.description=tx.description;document.querySelector('#dialog').close();await render();}));
    modal(t('Sablonjavaslat ellenőrzése','Review template suggestion'),preview);
  },true));
  const packed = async () => api("/studio/v1/pack", committed());
  add(
    side,
    add(
      el("div", undefined, "actions"),
      button(t("Privát mentés", "Save privately"), async () => {
        committed();
        const result = projectId
          ? await api("/studio/v1/projects/" + projectId, {
              title: m.title,
              revision,
              body: {...draft, studio:{price:Number(price.value)}},
            })
          : await api("/studio/v1/projects", { title: m.title, body: {...draft,studio:{price:Number(price.value)}} });
        projectId = result.id || projectId;
        revision = result.revision;
        await render();
        savedStudioFingerprint=studioFingerprint();persistStudio();
        notice.className = "";
        notice.textContent = t("Mentve.", "Saved.");
      }),
      button(
        t("Ellenőrzés", "Validate"),
        async () => {
          const p = await packed();
          const result = await api("/studio/v1/validate", p);
          modal(
            t("Sémaellenőrzés sikeres", "Schema validation passed"),
            add(el('div'),el('p',t('A csomag szerkezete és hordozhatósága rendben van. Az AI-próbát a boxon végezd el.','The package structure and portability are valid. Run the AI trial on the box.')),technical(t('Ellenőrzés részletei','Validation details'),{digest:result.digest,checks:result.checks,aiTrial:result.aiTrial})),
          );
        },
        true,
      ),
      button(
        t("Csomag letöltése", "Download package"),
        async () => {
          const p = await packed();
          save(unbase64(p.archive), m.packageId + "-" + m.version + ".vtaip");
        },
        true,
      ),
      button(t("Beküldés ellenőrzésre", "Submit for review"), async () => {
        const p = await packed();
        await api("/studio/v1/releases", {
          archive: p.archive,
          price: Number(price.value),
        });
        await render();
        notice.className = "";
        notice.textContent = t(
          "Beküldve. Az üzemeltető jóváhagyása után külön publikálható.",
          "Submitted. Publish separately after operator approval.",
        );
      },true),
    ),
  );
  const advanced = el("details");
  add(
    advanced,
    el(
      "summary",
      t(
        "Haladó beállítások",
        "Advanced settings",
      ),
    ),
  );
  raw = area(rawDraft ?? json(draft));
  raw.setAttribute('aria-label',t('Csomag JSON','Package JSON'));
  const rawNotice = el('p',undefined,'muted');
  const rawState = () => {
    editor.inert = rawDraft !== null;
    rawNotice.textContent = rawDraft === null ? t('Az űrlap és az export ugyanazt a tervezetet használja.','The form and export use the same draft.') : t('Mentetlen JSON: alkalmazd vagy vesd el a módosítást az űrlap folytatásához.','Unsaved JSON: apply or discard the changes to continue editing the form.');
  };
  raw.oninput = () => { rawDraft = raw.value;persistStudio(); rawState(); };
  advanced.ontoggle = () => { if(advanced.open)syncRaw(); };
  rawState();
  add(
    advanced,
    raw,
    rawNotice,
    button(
      t("JSON alkalmazása", "Apply JSON"),
      async () => {
        let next;
        try { next = JSON.parse(raw.value); }
        catch { throw new Error(t('A JSON nem értelmezhető. Ellenőrizd az idézőjeleket, vesszőket és zárójeleket.','Invalid JSON. Check quotes, commas and brackets.')); }
        await api("/studio/v1/pack", next);
        draft = next;
        rawDraft = null;
        return render();
      },
      true,
    ),
    button(t('JSON módosítás elvetése','Discard JSON changes'),()=>{rawDraft=null;raw.value=json(draft);rawState();},true),
  );
  side.append(advanced);
  view.append(releaseSection);
}
async function library() {
  header(
    t("Saját könyvtár és boxkapcsolatok", "My library and box connections"),
    t(
      "A vásárlás, a telepítés és az ügynök aktiválása külön művelet.",
      "Purchase, installation and agent activation are separate operations.",
    ),
  );
  const data = await api("/market/v1/library");
  const grid = el("div", undefined, "cards");
  view.append(grid);
  for (const e of data.entitlements) {
    const c = el("article", undefined, "card");
    add(
      c,
      el("h2", e.manifest.title),
      el("span", `v${e.manifest.version} · ${e.manifest.packageId}`,"badge"),
      el("span", rightName(e.kind), "badge info"),
      el(
        "p",
        (e.active
          ? t("Jogosultság aktív", "Entitlement active")
          : t("Jogosultság visszavonva", "Entitlement revoked")) +
          " · " +
          stateName(e.state),
      ),
    );
    if (e.active && e.kind !== "R")
      add(
        c,
        button(
          t("Csomag letöltése", "Download package"),
          async () =>
            save(
              await api("/market/v1/download/" + e.digest, undefined, true),
              e.manifest.packageId + ".vtaip",
            ),
          true,
        ),
      );
    if (e.active && e.kind === "D")
      add(
        c,
        button(
          t("Saját termék készítése", "Create derivative product"),
          async () => {
            if (!user.publisher)
              throw new Error(
                t(
                  "Előbb igényelj kiadói névteret a Studio-ban.",
                  "Request a publisher namespace in Studio first.",
                ),
              );
            const blob = await api(
                "/market/v1/download/" + e.digest,
                undefined,
                true,
              ),
              p = await api("/studio/v1/validate", {
                archive: await base64(blob),
              }),
              grant = data.grants.find(
                (g) => g.digest === e.digest && g.kind === "D" && g.active,
              );
            if (!grant)
              throw new Error(
                t("Nincs származtatási jog.", "No derivative right."),
              );
            draft = {
              manifest: {
                ...p.manifest,
                publisherId: user.publisher,
                packageId: user.publisher + ".sajat-valtozat",
                version: "1.0.0",
                derivedFrom: { digest: e.digest, grantId: grant.id },
                license: { ...p.manifest.license, derivatives: false },
              },
              templates: p.templates,
            };
            projectId = null;
            location.hash = "studio";
          },
        ),
      );
    if (e.active && e.kind === "R")
      add(
        c,
        button(
          t("Viszonteladói ajánlat létrehozása", "Create reseller offer"),
          async () => {
            const form = el("div"),
              price = field(
                form,
                t("Tesztár (HUF)", "Test price (HUF)"),
                input("1000", "number"),
              );
            add(
              form,
              button(t("Ajánlat publikálása", "Publish offer"), async () => {
                await api("/studio/v1/offers", {
                  digest: e.digest,
                  price: Number(price.value),
                });
                document.querySelector("#dialog").close();
                location.hash = "offers";
              }),
            );
            modal(t("Új viszonteladói ajánlat", "New reseller offer"), form);
          },
        ),
      );
    grid.append(c);
  }
  if (!data.entitlements.length)
    grid.append(
      empty(
        t(
          "Még nincs megszerzett csomag vagy jog.",
          "No acquired package or right yet.",
        ),
      ),
    );
  if (data.orders.length) {
    const orders = el("details");
    add(
      orders,
      el(
        "summary",
        t("Rendelések és tesztbizonylatok", "Orders and test receipts"),
      ),
    );
    for (const order of data.orders) {
      add(
        orders,
        add(
          el("div", undefined, "card"),
          el("strong", order.manifest.title + " / " + order.manifest.version),
          el("p", rightName(order.kind) + " • " + order.total + " HUF • " + stateName(order.state)),
          el("p", date(order.created)),
          technical(t("Rendelés és csomag részletei", "Order and package details"),{orderId:order.id,packageId:order.manifest.packageId,digest:order.digest}),
        ),
      );
      // A félbehagyott tesztrendelés ugyanazzal az azonosítóval folytatható.
      if (order.state === "pending")
        orders.append(button(t("Tesztvásárlás folytatása", "Resume test purchase"), async () => {
          const confirmation = el("div");
          add(confirmation,
            el("p", order.id + " • " + order.total + " HUF / " + order.kind),
            el("p", t("Nincs valódi fizetés. A meglévő tesztrendelést teljesítjük.", "No real payment. This completes the existing test order.")),
            button(t("Tesztvásárlás megerősítése", "Confirm test purchase"), async () => {
              await api("/market/v1/orders/" + order.id + "/local-test-complete", {});
              document.querySelector("#dialog").close();
              await render();
            }));
          modal(t("Tesztrendelés folytatása", "Resume test order"), confirmation);
        }));
    }
    view.append(orders);
  }
  const c = el("section", undefined, "card");
  c.classList.add("spaced");
  add(
    c,
    el("h2", t("Box összekapcsolása", "Connect a box")),
    el(
      "p",
      t(
        "A kapcsolat adatait csak a saját boxadmin-felületén add meg. A token egyszer jelenik meg; kezeld titokként.",
        "Enter connection details only in your own box admin interface. The token is shown once; keep it secret.",
      ),
    ),
  );
  const name = field(c, t("Box neve", "Box name"), input("Saját AI Box"));
  add(
    c,
    button(t("Kapcsolat létrehozása", "Create connection"), async () => {
      const b = await api("/market/v1/boxes", { name: name.value });
      modal(
        t("Egyszer megjelenített boxkapcsolat", "One-time box connection"),
        el("pre", json({ baseUrl: location.origin, ...b })),
      );
    }),
  );
  for (const b of data.boxes)
    add(
      c,
      add(
        el("div", undefined, "row"),
        el("p", b.name),
        button(
          t("Kapcsolat visszavonása", "Revoke connection"),
          async () => {
            await api("/market/v1/boxes/" + b.id + "/revoke", {});
            await render();
          },
          true,
        ),
      ),
    );
  view.append(c);
  if (user.publisher) {
    const ledger = await api("/studio/v1/ledger");
    add(
      view,
      el("h2", t("Kiadói tesztelszámolás", "Publisher test ledger")),
      el(
        "p",
        t(
          "Valódi kifizetés nincs. Az összegek a helyi tesztszabályt követik.",
          "No real payouts. Amounts follow the local test policy.",
        ),
      ),
    );
    const table = el("table", undefined, "table");
    add(
      table,
      add(
        el("tr"),
        el("th", t("Csomag és rendelés", "Package and order")),
        el("th", t("Tétel", "Entry")),
        el("th", "HUF"),
      ),
    );
    for (const l of ledger)
      add(
        table,
        add(
          el("tr"),
          add(el("td"),el('strong',l.manifest.title+' / '+l.manifest.version),el('p',date(l.created)),technical(t('Rendelésazonosító','Order identifier'),l.order_id)),
          el("td", l.kind==='refund'?t('Részesedés visszatérítése','Share refund'):t('Értékesítési részesedés','Sales share')),
          el("td", String(l.amount)),
        ),
      );
    view.append(table);
  }
}
async function offers() {
  header(
    t("Viszonteladói ajánlatok", "Reseller offers"),
    t(
      "Változatlan, eredeti csomag külön ajánlatként. A vásárló használati jogot kap.",
      "Unmodified original packages offered by resellers. Buyers receive a use license.",
    ),
  );
  const list = await api("/market/v1/offers"),
    grid = el("div", undefined, "cards");
  view.append(grid);
  for (const o of list) {
    const c = el("article", undefined, "card");
    add(
      c,
      el("h2", o.manifest.title),
      el("p", o.publisher + " • " + o.price + " HUF"),
      el("p", o.manifest.packageId + " / " + o.manifest.version),
      button(t("Helyi tesztvásárlás", "Local test purchase"), async () => {
        if (!requireUser()) return;
        const b = el("div");
        add(
          b,
          el(
            "p",
            t("Nincs valódi pénzmozgás. Ár: ", "No real payment. Price: ") +
              o.price +
              " HUF",
          ),
          button(
            t("Tesztvásárlás megerősítése", "Confirm test purchase"),
            async () => {
              const order = await api("/market/v1/orders", {
                digest: o.digest,
                offerId: o.id,
                kind: "U",
                idempotencyKey: crypto.randomUUID(),
              });
              await api(
                "/market/v1/orders/" + order.id + "/local-test-complete",
                {},
              );
              document.querySelector("#dialog").close();
              location.hash = "library";
            },
          ),
        );
        modal(o.manifest.title, b);
      }),
    );
    if (user?.publisher === o.publisher)
      add(
        c,
        button(
          t("Ajánlat visszavonása", "Withdraw offer"),
          async () => {
            await api("/studio/v1/offers/" + o.id + "/withdraw", {});
            await render();
          },
          true,
        ),
      );
    grid.append(c);
  }
  if (!list.length)
    grid.append(
      empty(
        t(
          "Még nincs aktív ajánlat. R-jog vásárlása után a Saját könyvtárból hozható létre.",
          "No active offers. Purchase an R grant and create an offer from My library.",
        ),
      ),
    );
}
async function operator() {
  if (!user.operator)
    throw new Error(
      t("Üzemeltetői jog szükséges.", "Operator permission required."),
    );
  header(
    t("Marketplace üzemeltetés", "Marketplace operations"),
    t(
      "A jóváhagyás nem jelent valódi AI-minősítést. A kiadó ezt követően külön publikál.",
      "Approval does not certify real AI behavior. Publishers publish separately afterwards.",
    ),
  );
  const projects=await api('/operator/v1/projects');
  const projectSection=add(el('details'),el('summary',t(`Privát projektek kezelése (${projects.length})`,`Manage private projects (${projects.length})`)));
  projectSection.append(el('p',t('Saját és más szerző privát projektje törölhető. A kiadások és a licencek megmaradnak.','You can delete your own or another author’s private project. Releases and licenses are retained.')));
  for(const project of projects){const card=add(el('div',undefined,'card'),el('strong',project.title),el('p',project.ownerEmail),button(t('Projekt törlése','Delete project'),()=>deleteProject(project),true));projectSection.append(card);}
  view.append(projectSection);
  const data = await api("/operator/v1/review");
  for (const p of data.publishers) {
    const c = el("div", undefined, "card");
    add(c, el("strong", p.publisher), el("p", p.email));
    if (!p.verified)
      add(
        c,
        button(t("Kiadó jóváhagyása", "Approve publisher"), async () => {
          await api("/operator/v1/publishers/" + p.id + "/approve", {});
          await render();
        }),
      );
    view.append(c);
  }
  for (const r of data.releases) {
    const c = el("div", undefined, "card");
    add(
      c,
      el("h2", r.manifest.title + " / " + r.manifest.version),
      el("span", stateName(r.state), "badge " + (r.state === "published" || r.state === "approved" ? "ok" : "warn")),
      technical(t("Csomag műszaki részletei", "Package technical details"),r.manifest),
    );
    // Jóváhagyott kiadást már a kiadó publikál: újraértékelése 409-et adna.
    if (r.state === "approved") {
      c.append(el("p", t("Jóváhagyva; a kiadó a Studio-ban publikálhatja.", "Approved; the publisher can publish it in Studio.")));
      view.append(c);
      continue;
    }
    const note = field(c, t("Vizsgálati megjegyzés", "Review note"), input());
    for (const [approved, hu, en] of [
      [true, "Séma és csomag jóváhagyása", "Approve schema and package"],
      [false, "Elutasítás", "Reject"],
    ])
      add(
        c,
        button(
          t(hu, en),
          async () => {
            await api("/operator/v1/releases/" + r.digest + "/review", {
              approved,
              note: note.value,
            });
            await render();
          },
          !approved,
        ),
      );
    view.append(c);
  }
  const tools = el("details");
  add(
    tools,
    el(
      "summary",
      t("Visszavonás és teszt-visszatérítés", "Revocation & test refund"),
    ),
  );
  const d = field(tools, t("Kiadás digest", "Release digest"), input()),
    o = field(tools, t("Rendelésazonosító", "Order ID"), input());
  add(
    tools,
    button(
      t("Kiadás tiltása", "Revoke release"),
      async () => {
        await api("/operator/v1/releases/" + d.value + "/revoke", {});
        await render();
      },
      true,
    ),
    button(
      t("Teljes teszt-visszatérítés", "Full test refund"),
      async () => {
        await api("/operator/v1/orders/" + o.value + "/refund", {});
        await render();
      },
      true,
    ),
  );
  view.append(tools);
}
function help() {
  header(
    t("SDK és működési súgó", "SDK & workflow help"),
    t(
      "Ugyanaz a csomagformátum a helyi fejlesztői eszközben, a Studio-ban és a boxon.",
      "The local SDK, Studio and box use the same package format.",
    ),
  );
  const download = el(
    "a",
    t(
      "Önálló SDK letöltése (Node.js 24)",
      "Download standalone SDK (Node.js 24)",
    ),
  );
  download.href = "/sdk/vtaip-sdk.tar.gz";
  download.download = "vtaip-sdk.tar.gz";
  view.append(download);
  const search = input();
  search.placeholder = t("Keresés a súgóban…", "Search help…");
  search.setAttribute("aria-label", search.placeholder);
  view.append(search);
  const list = el("div");
  view.append(list);
  const topics = [
    [
      t("Tesztadatok és tesztrendelések", "Test data and test orders"),
      t(
        "A TESZT jelölésű csomagok szintetikus példák. Próbáld ki a katalóguskeresést, a Studio privát mentését, a jóváhagyást, az U/D/R-jogokat és a boxtelepítést. A Saját könyvtár → Rendelések és tesztbizonylatok alatt a függő rendelés a Tesztvásárlás folytatása gombbal, külön megerősítés után teljesíthető. Az új verzió külön jogosultságot igényel. A csomagellenőrzés nem valódi AI-próba.",
        "Packages marked TESZT are synthetic examples. Try catalog search, private Studio saves, review, U/D/R grants and box installation. In My library → Orders and test receipts, a pending order can be completed with Resume test purchase and a separate confirmation. A new version needs its own entitlement. Package validation is not a real AI trial.",
      ),
    ],
    [
      t("Sablonkészítés", "Authoring"),
      t(
        "Studio → kiadói névtér → új sablon. A privát mentés nem publikálás. Az SDK init, validate, pack és inspect parancsai offline működnek.",
        "Studio → publisher namespace → new template. Private saves do not publish. SDK init, validate, pack and inspect work offline.",
      ),
    ],
    [
      t("Jóváhagyás és publikálás", "Review and publishing"),
      t(
        "Beküldés után üzemeltető ellenőrzi a kiadót és a csomagot. A kiadó ezután publikálhat. A helyi ügynökpróba a boxon kötelező; a modellprofil lehet szimulált.",
        "An operator reviews the publisher and package after submission. The publisher can then publish. A local agent trial remains mandatory on the box; the model profile may be simulated.",
      ),
    ],
    [
      t("Vásárlás és telepítés", "Purchase and installation"),
      t(
        "Ez helyi tesztkörnyezet. A tesztvásárlás jogosultságot ad, de valódi pénzt nem mozgat. A box Marketplace oldalán terv, engedélyezés, telepítés, majd saját ügynök és próba következik.",
        "This is a local test environment. Test purchases grant entitlements but do not move money. Use the box Marketplace to plan, approve and install, then create and trial your agent.",
      ),
    ],
    [
      t("Továbbértékesítés", "Derivative sales"),
      t(
        "D-joggal a Könyvtárból saját termék indítható. Új kiadó/azonosító és megőrzött szülődigest szükséges. Az első kiadás egy eredeti szülőt támogat.",
        "A D grant allows creating a derivative from Library. A new publisher/ID and preserved parent digest are required. This version supports one original parent.",
      ),
    ],
    [
      t("Adatvédelem és boxkapcsolat", "Data and box connection"),
      t(
        "Ne tölts ügyféliratot vagy titkot a Studio-ba. A boxkapcsolat tokene csak egyszer jelenik meg. A csomagban nincsenek helyi mappakötések; ezeket a boxon kell kiválasztani.",
        "Do not upload customer documents or secrets to Studio. Box connection tokens are shown once. Packages carry no local folder bindings; choose these on the box.",
      ),
    ],
  ];
  const draw = () => {
    list.replaceChildren();
    for (const [title, body] of topics.filter((x) =>
      x.join(" ").toLowerCase().includes(search.value.toLowerCase()),
    ))
      add(
        list,
        add(el("section", undefined, "card"), el("h2", title), el("p", body)),
      );
  };
  search.oninput = draw;
  draw();
  add(
    view,
    el(
      "pre",
      "npm run marketplace:sdk --prefix app\nnode marketplace/dist/sdk/lib/server/marketplace/cli.js init ./uj-sablon\nnode marketplace/dist/sdk/lib/server/marketplace/cli.js pack ./uj-sablon/project.json ./ugynok.vtaip\nnode marketplace/dist/sdk/lib/server/marketplace/cli.js inspect ./ugynok.vtaip",
    ),
  );
}
document.querySelector("#locale").value = locale;
// Nyelvváltáskor az űrlapmezők és a lenyitott részek helyzete is megmarad.
document.querySelector("#locale").onchange = async (e) => {
  const controls = [...view.querySelectorAll("input,textarea,select")].map(node => ({value:node.value, checked:node.checked, type:node.type}));
  const expanded = [...view.querySelectorAll("details")].map(node => node.open);
  locale = e.target.value;
  try { localStorage.setItem("market.locale", locale); } catch {}
  await render();
  [...view.querySelectorAll("input,textarea,select")].forEach((node,i) => {const saved=controls[i];if(saved && saved.type===node.type){if(node.type!=="file")node.value=saved.value; if(node.type==="checkbox")node.checked=saved.checked;}});
  [...view.querySelectorAll("details")].forEach((node,i) => {node.open=expanded[i] || false;});
};
document.querySelector('.skip-link').onclick=e=>{e.preventDefault();document.querySelector('#main').focus();};
try {document.documentElement.dataset.theme=localStorage.getItem('market.theme')==='light'?'light':'dark';}catch{}
document.querySelector('#theme').onclick=()=>{const value=document.documentElement.dataset.theme==='light'?'dark':'light';document.documentElement.dataset.theme=value;try{localStorage.setItem('market.theme',value);}catch{}syncShell();};
document.querySelector('.brand-symbol').append(icon('bot'));
document.querySelector('#help-toggle').onclick=()=>helpOpen?closeHelp():openHelp();
document.querySelector('#nav-toggle').onclick=()=>{const open=!document.body.classList.contains('nav-open');document.body.classList.toggle('nav-open',open);document.querySelector('#nav-backdrop').hidden=!open;document.querySelector('#nav-toggle').setAttribute('aria-expanded',String(open));document.querySelector('#sidebar').inert=!open;if(open)document.querySelector('#nav a')?.focus();};
document.querySelector('#nav-backdrop').onclick=navClose;
document.addEventListener('keydown',e=>{const editing=e.target.matches('input,textarea,select');if(e.key==='F1'||(!editing&&e.key==='?')){e.preventDefault();openHelp(document.querySelector('#dialog').open?'rights':undefined);}if(e.key==='Escape'){if(helpOpen){e.preventDefault();closeHelp();}if(document.body.classList.contains('nav-open')){navClose();document.querySelector('#nav-toggle').focus();}}if(e.key==='Tab'&&helpOpen&&matchMedia('(max-width:1200px)').matches){const nodes=[...document.querySelector('#help-panel').querySelectorAll('button,input,a')].filter(x=>x.offsetParent!==null);const first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}});
document.querySelector("#logout").onclick = async () => {
  try {
    await api("/market/v1/logout", {});
  } finally {
    token = "";
    user = null;
    draft = null;
    sessionStorage.removeItem("market.token");
    location.hash = "login";
    render();
  }
};
matchMedia('(max-width:850px)').addEventListener('change',()=>{navClose();syncHelpMode();});matchMedia('(max-width:1200px)').addEventListener('change',syncHelpMode);navClose();
window.onhashchange = render;
if (token) {
  try {
    user = await api("/market/v1/me");
  } catch {
    token = "";
    sessionStorage.removeItem("market.token");
  }
}
await render();
